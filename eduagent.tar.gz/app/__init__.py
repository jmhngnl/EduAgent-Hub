"""EduAgent Hub application package."""
